// Gera o site estático (dados + páginas + ícones) a partir de ../all-ref.xls
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const XLSX = require('xlsx');

const SRC = path.join(__dirname, '..', 'all-ref.xls');
const OUT = path.join(__dirname, '..');

const CATEGORIES = [
  { slug: 'apoios-silentblocos-batentes', name: 'Apoios, silentblocos e batentes', desc: 'Apoios de motor e suspensão, apoios redondos, silentblocos e batentes.',
    prefixes: 'APMT APRE BBES BBPR BBPO BBPA BBCA BATE BSPE SLBL SPCR CPSA TRES ESTI FBSY' },
  { slug: 'borrachas-travao-capot', name: 'Borrachas de travão e capot', desc: 'Borrachas de travão, botões de capot e capas de pedal.',
    prefixes: 'BOTR BOTRC BTCP CAPA' },
  { slug: 'casquilhos', name: 'Casquilhos', desc: 'Casquilhos de borracha, nitrílicos, nylon e ferro.',
    prefixes: 'CSBO CSNI CSNY CSFE' },
  { slug: 'rodas-rodizios', name: 'Rodas e rodízios', desc: 'Rodízios, rodas, rolamentos, roletes, pneus e câmaras de ar.',
    prefixes: 'RODI RODA ROLA ROLE PNEU CAMA CHUM TAXA' },
  { slug: 'tubos-auto-silicone', name: 'Tubos auto e silicone', desc: 'Tubos de radiador, silicone, travão, combustível e respetivas uniões.',
    prefixes: 'UNTR MASA MAEA TUTR TUCX TOAT', regex: /^TB(?!HE|EZ|EI|EA)/ },
  { slug: 'tubos-mangueiras', name: 'Tubos e mangueiras industriais', desc: 'Mangueiras e tubos espirais, de condução de água e outros fluidos.',
    prefixes: 'TBHE' },
  { slug: 'escape', name: 'Escape', desc: 'Anéis, flexíveis, tubos e ponteiras de escape.',
    prefixes: 'AESC ANCE FLE TBEZ TBEI TBEA PNES' },
  { slug: 'foles', name: 'Foles', desc: 'Foles italianos e de proteção de rótulas.',
    prefixes: 'FLIT FLNA' },
  { slug: 'tacos-topos-ponteiras', name: 'Tacos, topos e ponteiras', desc: 'Tacos, topos, niveladores, ponteiras, tampas e tarugos de borracha.',
    prefixes: 'TACO TOPO NIVE TATU TAIN TCBL TUBI PTPL PTBR PTML PTAS TAPA TAMP TPOS ROBR TRBR TRBF' },
  { slug: 'folhas-placas-varoes', name: 'Folhas, placas e varões', desc: 'Folhas de borracha, placas técnicas, espumas, varões e tarugos.',
    prefixes: 'FOLA ESPU TRNY TRNP TRPA TRPU TRPE TRTE TRPV TPOM PPOM', regex: /^(FOB|PL[A-Z]*$)/ },
  { slug: 'perfis-vedantes-fitas', name: 'Perfis, vedantes e fitas', desc: 'Perfis de borracha, vedantes, fitas, tiras e cordões.',
    prefixes: 'VEPO FRPL JBCV JUVE CAJU CORR VENT OMAQ FITA FIRE FIDEST FIME TIBR TIES TIBS TIAE COBR COES COBS CORD', regex: /^(VD|PF)/ },
  { slug: 'molas-freios-fixacoes', name: 'Molas, freios e fixações', desc: 'Molas de painel e fixação, freios, porcas, rebites, parafusos e cavilhas.',
    prefixes: 'CVEL CVMO PORA POEN PORE REAL REPL PAFS PAPP SPEC FREX FRIN FREC FRECSO CHAV DPML', regex: /^MO/ },
  { slug: 'anilhas-orings', name: 'Anilhas e O-rings', desc: 'Anilhas de borracha, cobre, fibra, alumínio, plástico e O-rings.',
    prefixes: 'ANDV ANCO ANAM ANCA ANFI ANPL ANBU ANBR CEGA ANML ORIN' },
  { slug: 'unioes-buchas-passa-fios', name: 'Uniões, buchas e passa-fios', desc: 'Uniões rápidas, buchas, passa-fios e acessórios de ligação.',
    prefixes: 'ANPS BUCI BUCIRR BUCIRP CTPR ACRJ TEES UPES UNRP UNSP UNCR UNTO', regex: /^UN/ },
  { slug: 'abracadeiras', name: 'Abraçadeiras', desc: 'Abraçadeiras inox, metálicas, plásticas, super e para foles.',
    prefixes: '', regex: /^AB/ },
  { slug: 'manipulos-ferragens', name: 'Manípulos, puxadores e ferragens', desc: 'Manípulos, punhos, puxadores, pegas e dobradiças.',
    prefixes: 'MANI PUNH PEGA DOBR PEDX PUCP' },
  { slug: 'pecas-auto', name: 'Peças auto diversas', desc: 'Iluminação, retrovisores, kits de reparação e outras peças auto.',
    prefixes: 'ESRE ESLV FARL VIFP VIES LAMP LAMPPX CHMT CHLV CHRF REFL KITT BUJO CARD POLI GARRA CABO TEIM TEIB TEIN TEIC ENGA FCRB SNRB CTCO ISVE FLKT VASO VASF CVID CLUM PROM GDLM AUPV FLTR ESFE',
    regex: /^(KIT|TEI)/ },
  { slug: 'tapetes-pavimentos', name: 'Tapetes e pavimentos', desc: 'Tapetes de borracha, PVC e têxteis e pavimentos.',
    prefixes: 'TABO TACN TATE' },
  { slug: 'utilidades-embalagem', name: 'Utilidades, colas e embalagem', desc: 'Colas, lubrificantes, contentores, baldes, sacos, EPI e sinalização.',
    prefixes: 'CONT CAST BALD BIDO BIDA BIDG GAME CANE FUNI PALE ESTR SAPL SAPP MNPL MNPP PSIN CONE LUVA VEST BOTA FACH DELA EPIS BACI TSTL REDE LUBE COLA BOMB SUFE CISG ELPB ELAS CORDA CRNY ETPL LANT GAMB PULV' },
  { slug: 'diversos', name: 'Diversos', desc: 'Restantes artigos.', prefixes: '' }
];
const EXCLUDED = new Set(['NC', 'ND', 'ANTE', 'SER', 'TESTE', 'EQUI', 'ECON']);
const SKIP_GROUPS = new Set(['ACERTO CONTABILISTICO', 'ARTIGOS INACTIVOS', 'ECONOMATO']);

const exact = new Map();
CATEGORIES.forEach((c, i) => c.prefixes.split(' ').filter(Boolean).forEach(p => exact.set(p, i)));
const fallback = CATEGORIES.length - 1;
function categorize(prefix) {
  if (exact.has(prefix)) return exact.get(prefix);
  const i = CATEGORIES.findIndex(c => c.regex && c.regex.test(prefix));
  return i === -1 ? fallback : i;
}

const wb = XLSX.readFile(SRC);
const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' });
const items = [];
let group = '';
rows.forEach((r, i) => {
  if (i < 6) return;
  const c = r.map(v => (typeof v === 'string' ? v.trim() : v));
  if (c[2] && !c[3]) { group = String(c[2]); return; }
  const code = String(c[3] || '');
  if (!code || typeof c[17] !== 'number') return;
  const prefix = code.replace(/[0-9].*$/, '');
  if (EXCLUDED.has(prefix) || SKIP_GROUPS.has(group)) return;
  const flags = (c[8] === 'CONSIGNAÇÃO' ? 1 : 0) | (group.startsWith('DESCONTINUADOS') ? 2 : 0);
  items.push([code, String(c[5]).replace(/\s+/g, ' '), prefix, Number(c[12]) || 0, Math.round(c[17] * 100) / 100, flags]);
});

// Cada prefixo de referência (TBRA, CSBO, ...) é uma categoria; a família serve de subtítulo.
const byPrefix = new Map();
items.forEach(it => {
  if (!byPrefix.has(it[2])) byPrefix.set(it[2], { slug: it[2].toLowerCase(), name: it[2], desc: CATEGORIES[categorize(it[2])].name, sample: it[1], count: 0 });
  byPrefix.get(it[2]).count++;
});
const sortedCats = [...byPrefix.values()].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
sortedCats.forEach(c => { if (c.desc === 'Diversos') c.desc = c.sample; delete c.sample; });
const index = new Map(sortedCats.map((c, i) => [c.name, i]));
items.forEach(it => { it[2] = index.get(it[2]); });
items.sort((a, b) => a[2] - b[2] || a[0].localeCompare(b[0]));

fs.rmSync(path.join(OUT, 'categoria'), { recursive: true, force: true });
for (const d of ['data', 'categoria', 'icons']) fs.mkdirSync(path.join(OUT, d), { recursive: true });
fs.writeFileSync(path.join(OUT, 'data', 'categorias.json'), JSON.stringify({ total: items.length, cats: sortedCats }));
fs.writeFileSync(path.join(OUT, 'data', 'artigos.json'), JSON.stringify({ cats: sortedCats.map(c => [c.slug, c.name]), items }));

const esc = s => s.replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
function layout({ page, root, title, desc, body, cat = '' }) {
  const nav = [['index.html', 'Início', 'home'], ['artigos.html', 'Artigos', 'artigos'], ['categorias.html', 'Categorias', 'categorias']]
    .map(([h, t, p]) => `<a href="${root}${h}"${page === p || (p === 'categorias' && page === 'categoria') ? ' aria-current="page"' : ''}>${t}</a>`).join('');
  return `<!doctype html>
<html lang="pt-PT">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#173f45">
<meta name="description" content="${esc(desc)}">
<title>${esc(title)} · Plasti Borracha</title>
<link rel="manifest" href="${root}manifest.webmanifest">
<link rel="icon" href="${root}icons/icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="${root}icons/icon-192.png">
<link rel="stylesheet" href="${root}css/styles.css">
</head>
<body data-page="${page}" data-root="${root}"${cat ? ` data-cat="${cat}"` : ''}>
<header class="site-header">
  <a class="brand" href="${root}index.html"><span class="logo" aria-hidden="true"></span>Plasti <b>Borracha</b></a>
  <nav aria-label="Principal">${nav}</nav>
</header>
<main class="shell">
${body}
</main>
<footer class="site-footer"><span>PLASTI BORRACHA / ARTIGOS</span><span id="offline-status"></span></footer>
<script src="${root}js/app.js" defer></script>
</body>
</html>
`;
}

const listBlock = `
  <div class="toolbar">
    <label class="search"><span class="sr-only">Pesquisar</span><input id="q" type="search" placeholder="Pesquisar por referência ou descrição…" autocomplete="off"></label>
    <label class="select"><span>Ordenar</span><select id="sort">
      <option value="code">Referência</option>
      <option value="desc">Descrição</option>
      <option value="price-asc">Preço ↑</option>
      <option value="price-desc">Preço ↓</option>
      <option value="stock-desc">Stock ↓</option>
    </select></label>
    <label class="check"><input id="stockonly" type="checkbox"> Só com stock</label>
    <label class="check"><input id="disc" type="checkbox"> Incluir descontinuados</label>
  </div>
  <p id="count" class="count" aria-live="polite"></p>
  <div id="list" class="grid"></div>
  <p id="empty" class="empty" hidden>Nenhum artigo encontrado.</p>
  <div class="more"><button id="more" class="btn" hidden>Mostrar mais</button></div>
  <dialog id="detail"></dialog>`;

const pages = {
  'index.html': layout({
    page: 'home', root: '', title: 'Início', desc: 'Consulte os artigos Plasti Borracha por categoria.',
    body: `<section class="hero">
  <p class="eyebrow">Biblioteca de artigos</p>
  <h1>Todos os <em>artigos.</em></h1>
  <p class="lede">Consulte as referências Plasti Borracha, organizadas por categoria, com pesquisa instantânea e disponibilidade offline.</p>
  <div class="hero-actions"><a class="btn primary" href="artigos.html">Ver todos os artigos</a><a class="btn" href="categorias.html">Ver categorias</a></div>
  <dl class="stats" id="stats"></dl>
</section>
<section>
  <div class="section-head"><h2>Principais categorias</h2><a href="categorias.html">Todas →</a></div>
  <div id="cat-grid" class="cat-grid" data-limit="6"></div>
</section>`
  }),
  'artigos.html': layout({
    page: 'artigos', root: '', title: 'Artigos', desc: 'Lista completa de artigos Plasti Borracha.',
    body: `<section class="page-head"><p class="eyebrow">Catálogo completo</p><h1>Artigos</h1></section>
<div class="filters"><label class="select wide"><span>Categoria</span><select id="catfilter"><option value="">Todas as categorias</option></select></label></div>${listBlock}`
  }),
  'categorias.html': layout({
    page: 'categorias', root: '', title: 'Categorias', desc: 'Categorias de artigos Plasti Borracha.',
    body: `<section class="page-head"><p class="eyebrow">Explorar</p><h1>Categorias</h1></section>
<label class="search cat-search"><span class="sr-only">Pesquisar categorias</span><input id="catq" type="search" placeholder="Pesquisar categoria (ex.: TBRA, casquilhos)…" autocomplete="off"></label>
<p id="catcount" class="count" aria-live="polite"></p>
<div id="cat-grid" class="cat-grid"></div>`
  })
};
sortedCats.forEach((c, i) => {
  pages[`categoria/${c.slug}.html`] = layout({
    page: 'categoria', root: '../', title: c.name, desc: c.desc, cat: String(i),
    body: `<nav class="crumbs" aria-label="Localização"><a href="../categorias.html">Categorias</a> / <span>${esc(c.name)}</span></nav>
<section class="page-head"><p class="eyebrow">${c.count} artigos</p><h1>${esc(c.name)}</h1><p class="lede">${esc(c.desc)}</p></section>${listBlock}`
  });
});
for (const [file, html] of Object.entries(pages)) fs.writeFileSync(path.join(OUT, file), html);

fs.writeFileSync(path.join(OUT, 'icons', 'icon.svg'),
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="96" fill="#173f45"/><circle cx="256" cy="256" r="150" fill="none" stroke="#e76f51" stroke-width="86"/></svg>');

function png(size) {
  const bg = [0x17, 0x3f, 0x45], fg = [0xe7, 0x6f, 0x51];
  const stride = size * 4 + 1;
  const raw = Buffer.alloc(stride * size);
  const c = size / 2, rMid = size * 0.293, half = size * 0.084, rr = size * 0.1875;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const o = y * stride + 1 + x * 4;
      const dx = Math.min(x, size - 1 - x), dy = Math.min(y, size - 1 - y);
      const inside = !(dx < rr && dy < rr) || Math.hypot(rr - dx, rr - dy) <= rr;
      const col = Math.abs(Math.hypot(x + .5 - c, y + .5 - c) - rMid) <= half ? fg : bg;
      raw[o] = col[0]; raw[o + 1] = col[1]; raw[o + 2] = col[2]; raw[o + 3] = inside ? 255 : 0;
    }
  }
  const table = Array.from({ length: 256 }, (_, n) => { let v = n; for (let k = 0; k < 8; k++) v = v & 1 ? 0xedb88320 ^ (v >>> 1) : v >>> 1; return v >>> 0; });
  const crc = buf => { let v = 0xffffffff; for (const b of buf) v = table[(v ^ b) & 255] ^ (v >>> 8); return (v ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const cr = Buffer.alloc(4); cr.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, cr]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
fs.writeFileSync(path.join(OUT, 'icons', 'icon-192.png'), png(192));
fs.writeFileSync(path.join(OUT, 'icons', 'icon-512.png'), png(512));

fs.writeFileSync(path.join(OUT, 'manifest.webmanifest'), JSON.stringify({
  name: 'Plasti Borracha · Artigos', short_name: 'Artigos', lang: 'pt-PT', start_url: './index.html', scope: './',
  display: 'standalone', background_color: '#f4f7f4', theme_color: '#173f45',
  icons: [
    { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
    { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' }
  ]
}, null, 2));
const shell = ['./', 'index.html', 'artigos.html', 'categorias.html', ...sortedCats.map(c => `categoria/${c.slug}.html`),
  'css/styles.css', 'js/app.js', 'data/categorias.json', 'data/artigos.json', 'manifest.webmanifest', 'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png'];
fs.writeFileSync(path.join(OUT, 'sw.js'), fs.readFileSync(path.join(__dirname, 'sw.template.js'), 'utf8')
  .replace('__VERSION__', Date.now().toString(36)).replace('__SHELL__', JSON.stringify(shell)));

console.log(`${items.length} artigos, ${sortedCats.length} categorias`);
sortedCats.forEach(c => console.log(String(c.count).padStart(5), c.name));
